module.exports = {

 StringList:  {
    text: {
        text: [
            
            
        ]
    }
},
Button:{
    text:"Name",
    postback:"value"
}

}

